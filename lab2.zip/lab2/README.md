# CSE-3150 lab2
complie fisherYates.cpp(include unit tests):
g++ -std=c++17 fisherYates.cpp -o fisher

excute:
./fisher